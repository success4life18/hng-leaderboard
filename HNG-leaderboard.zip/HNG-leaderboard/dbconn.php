<?php

$host = 'localhost';
$user = 'root';
$db = 'leaderboard';
$pass = '';

$conn = mysqli_connect($host, $user, $pass, $db);
 
if ($conn) {
    
} else die('Failed to connect')

?>